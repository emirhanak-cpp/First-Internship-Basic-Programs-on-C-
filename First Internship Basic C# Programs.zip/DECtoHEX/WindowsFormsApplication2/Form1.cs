﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//TODO: NumericUpDown içinde yazan sayı hexdecimalformatta Textbox a yazan kod eklenecek.
//uint64 range aralığında numericUpDown değer alabilecek.
//Example; NumericUpDown=5 --> Textbox = 0x05
//Example; NumericUpDown=10 --> Textbox = 0x0A
//Example; NumericUpDown=255 --> Textbox = 0xFF

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.numericUpDown1.Minimum = UInt64.MinValue;
            this.numericUpDown1.Maximum = UInt64.MaxValue;
            this.numericUpDown2.Minimum = UInt64.MinValue;
            this.numericUpDown2.Maximum = UInt64.MaxValue;
        }

        ulong boxvalue;
        string hexvalue;

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (Convert.ToUInt64(numericUpDown1.Value) > UInt64.MaxValue)
            {
                boxvalue = UInt64.MaxValue;
            }
            else
            {
                boxvalue = Convert.ToUInt64(numericUpDown1.Value);
            }
            
            hexvalue = boxvalue.ToString("X16");

            textBox1.Text = "0x" + hexvalue;
        }

        /*
         * private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
        }
        */

        /*
         * private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
        */

     

        /*
         * private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        */

        private void button2_Click(object sender, EventArgs e)
        {
            string text = textBox2.Text;
            try
            {
                ulong converted = Convert.ToUInt64(text, 16);
                numericUpDown2.Value = converted;
            }
            catch (OverflowException)
            {
                MessageBox.Show("The number is too big for unsigned integer. Try again.");
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Please enter a value.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a HEX value.");
            }
            catch
            {
                MessageBox.Show("Unexpected error. Try again.");
            }
        }
    }



        /*
         * private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }
        */
    }