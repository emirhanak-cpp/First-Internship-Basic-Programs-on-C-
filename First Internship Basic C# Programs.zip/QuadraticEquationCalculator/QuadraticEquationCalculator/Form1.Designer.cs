﻿namespace QuadraticEquationCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.a = new System.Windows.Forms.NumericUpDown();
            this.b = new System.Windows.Forms.NumericUpDown();
            this.c = new System.Windows.Forms.NumericUpDown();
            this.answerText = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.x = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.x)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ax^(2) + bx + c = 0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "a = ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "b = ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "c = ";
            // 
            // a
            // 
            this.a.DecimalPlaces = 2;
            this.a.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.a.Location = new System.Drawing.Point(76, 37);
            this.a.Maximum = new decimal(new int[] {
            0,
            0,
            50,
            131072});
            this.a.Minimum = new decimal(new int[] {
            0,
            0,
            50,
            -2147352576});
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(48, 20);
            this.a.TabIndex = 4;
            this.a.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b
            // 
            this.b.DecimalPlaces = 2;
            this.b.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.b.Location = new System.Drawing.Point(76, 63);
            this.b.Maximum = new decimal(new int[] {
            0,
            0,
            50,
            131072});
            this.b.Minimum = new decimal(new int[] {
            0,
            0,
            50,
            -2147352576});
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(48, 20);
            this.b.TabIndex = 5;
            this.b.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // c
            // 
            this.c.DecimalPlaces = 2;
            this.c.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.c.Location = new System.Drawing.Point(76, 89);
            this.c.Maximum = new decimal(new int[] {
            0,
            0,
            50,
            131072});
            this.c.Minimum = new decimal(new int[] {
            0,
            0,
            50,
            -2147352576});
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(48, 20);
            this.c.TabIndex = 6;
            this.c.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // answerText
            // 
            this.answerText.Location = new System.Drawing.Point(48, 170);
            this.answerText.Name = "answerText";
            this.answerText.ReadOnly = true;
            this.answerText.Size = new System.Drawing.Size(76, 20);
            this.answerText.TabIndex = 7;
            this.answerText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(48, 141);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(76, 23);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // x
            // 
            this.x.DecimalPlaces = 2;
            this.x.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.x.Location = new System.Drawing.Point(76, 115);
            this.x.Maximum = new decimal(new int[] {
            0,
            0,
            50,
            131072});
            this.x.Minimum = new decimal(new int[] {
            0,
            0,
            50,
            -2147352576});
            this.x.Name = "x";
            this.x.Size = new System.Drawing.Size(48, 20);
            this.x.TabIndex = 9;
            this.x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "x = ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(176, 205);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.x);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.answerText);
            this.Controls.Add(this.c);
            this.Controls.Add(this.b);
            this.Controls.Add(this.a);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Quadratic Equation Solver";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.x)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown a;
        private System.Windows.Forms.NumericUpDown b;
        private System.Windows.Forms.NumericUpDown c;
        private System.Windows.Forms.TextBox answerText;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.NumericUpDown x;
        private System.Windows.Forms.Label label5;
    }
}

