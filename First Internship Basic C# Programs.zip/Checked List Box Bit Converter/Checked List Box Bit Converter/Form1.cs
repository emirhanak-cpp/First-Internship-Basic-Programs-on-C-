﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Checked_List_Box_Bit_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int i;
        bool[] bits;
        int[] intbit;
        string bitstr;
        //string bitstrfin;
        ulong number;
        string hex;



    

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0x" + chlxToHex(checkedListBox1);
        }



        private string chlxToHex(CheckedListBox chlx)
        {
            //TODO: Checklistbox içerisindeki checked durumunda olan ibarelere bakılarak hexadecimal değer üreten ve bu metin formatında veren fonksiyon yazmak.
            string result = "";

            bits = new bool[chlx.Items.Count];
            intbit = new int[chlx.Items.Count];

            for (i = 0; i < chlx.Items.Count; i++)
            {
                bits[i] = chlx.GetItemChecked(i);

                if (bits[i])
                {
                    intbit[i] = 1;
                }
                else
                {
                    intbit[i] = 0;
                }
            }

            bitstr = string.Join("", intbit);
            char[] strchar = bitstr.ToCharArray();
            Array.Reverse(strchar);
            string bitstrfin = new string(strchar);
            //Console.WriteLine(bitstrfin);

            number = Convert.ToUInt64(bitstrfin, 2);
            hex = number.ToString("X16");
            result = hex;
            return result;
        }

        ulong decnum;
        ulong[] binarr;
        //int intnum;

        private void button2_Click(object sender, EventArgs e)
        {
            HexTochlx(textBox2.Text);
            
            
        }

        private void HexTochlx(string hexstring)
        {
            binarr = new ulong[checkedListBox2.Items.Count];
            try
            {
                for (int i = 0; i < checkedListBox2.Items.Count; i++)
                {
                    binarr[i] = 0;
                }
                //binarr = new ulong[] { 0, 0, 0, 0, 0, 0, 0, 0 };

                //for (int j = 0; j < checkedListBox2.Items.Count; j++)
                //{
                //    checkedListBox2.SetItemChecked(j, false);
                //}
                hexstring = textBox2.Text;
                decnum = Convert.ToUInt64(hexstring, 16);
                //Console.WriteLine(decnum);
                ulong temp = decnum;

                for (i = 0; temp > 0; i++)
                {
                    binarr[i] = temp % 2;
                    temp = temp / 2;
                    Console.WriteLine(binarr[i]);
                }

                for (i = 0; i < checkedListBox2.Items.Count; i++)
                {
                    if (binarr[i] == 1)
                    {
                        checkedListBox2.SetItemChecked(i, true);
                    }
                    else
                    {
                        checkedListBox2.SetItemChecked(i, false);
                    }
                }

                /*
                Array.Reverse(binarr);
                string binary = string.Join("", binarr);
                Console.WriteLine(binary);
                */
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Please enter a value.");
                //MessageBox.Show(ex.Message);
            }
            return;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            clerallfunc(checkedListBox1);
        }

        private void clerallfunc(CheckedListBox chlx1)
        {
            for (int i = 0; i < chlx1.Items.Count; i++)
            {
                chlx1.SetItemChecked(i, false);
            }
            return;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            checkallfunc(checkedListBox1);
        }

        private void checkallfunc(CheckedListBox chlx1)
        {
            for (int i = 0; i < chlx1.Items.Count; i++)
            {
                chlx1.SetItemChecked(i, true);
            }
           
            return;
        }
    }
}
