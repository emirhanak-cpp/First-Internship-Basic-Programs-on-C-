﻿namespace Checked_List_Box_Bit_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkedListBox2 = new System.Windows.Forms.CheckedListBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Bit 0",
            "Bİt 1",
            "Bit 2",
            "Bit 3",
            "Bit 4",
            "Bit 5",
            "Bit 6",
            "Bit 7",
            "Bit 8",
            "Bİt 9",
            "Bit 10",
            "Bit 11",
            "Bit 12",
            "Bit 13",
            "Bit 14",
            "Bit 15",
            "Bit 16",
            "Bİt 17",
            "Bit 18",
            "Bit 19",
            "Bit 20",
            "Bit 21",
            "Bit 22",
            "Bit 23",
            "Bit 24",
            "Bİt 25",
            "Bit 26",
            "Bit 27",
            "Bit 28",
            "Bit 29",
            "Bit 30",
            "Bit 31",
            "Bit 32",
            "Bİt 33",
            "Bit 34",
            "Bit 35",
            "Bit 36",
            "Bit 37",
            "Bit 38",
            "Bit 39",
            "Bit 40",
            "Bİt 41",
            "Bit 42",
            "Bit 43",
            "Bit 44",
            "Bit 45",
            "Bit 46",
            "Bit 47",
            "Bit 48",
            "Bİt 49",
            "Bit 50",
            "Bit 51",
            "Bit 52",
            "Bit 53",
            "Bit 54",
            "Bit 55",
            "Bit 56",
            "Bİt 57",
            "Bit 58",
            "Bit 59",
            "Bit 60",
            "Bit 61",
            "Bit 62",
            "Bit 63"});
            this.checkedListBox1.Location = new System.Drawing.Point(12, 39);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(120, 484);
            this.checkedListBox1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.textBox1.Location = new System.Drawing.Point(12, 529);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(12, 600);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Convert";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkedListBox2
            // 
            this.checkedListBox2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.checkedListBox2.FormattingEnabled = true;
            this.checkedListBox2.Items.AddRange(new object[] {
            "Bit 0",
            "Bİt 1",
            "Bit 2",
            "Bit 3",
            "Bit 4",
            "Bit 5",
            "Bit 6",
            "Bit 7",
            "Bit 8",
            "Bİt 9",
            "Bit 10",
            "Bit 11",
            "Bit 12",
            "Bit 13",
            "Bit 14",
            "Bit 15",
            "Bit 16",
            "Bİt 17",
            "Bit 18",
            "Bit 19",
            "Bit 20",
            "Bit 21",
            "Bit 22",
            "Bit 23",
            "Bit 24",
            "Bİt 25",
            "Bit 26",
            "Bit 27",
            "Bit 28",
            "Bit 29",
            "Bit 30",
            "Bit 31",
            "Bit 32",
            "Bİt 33",
            "Bit 34",
            "Bit 35",
            "Bit 36",
            "Bit 37",
            "Bit 38",
            "Bit 39",
            "Bit 40",
            "Bİt 41",
            "Bit 42",
            "Bit 43",
            "Bit 44",
            "Bit 45",
            "Bit 46",
            "Bit 47",
            "Bit 48",
            "Bİt 49",
            "Bit 50",
            "Bit 51",
            "Bit 52",
            "Bit 53",
            "Bit 54",
            "Bit 55",
            "Bit 56",
            "Bİt 57",
            "Bit 58",
            "Bit 59",
            "Bit 60",
            "Bit 61",
            "Bit 62",
            "Bit 63"});
            this.checkedListBox2.Location = new System.Drawing.Point(156, 94);
            this.checkedListBox2.Name = "checkedListBox2";
            this.checkedListBox2.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.checkedListBox2.Size = new System.Drawing.Size(120, 529);
            this.checkedListBox2.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.textBox2.Location = new System.Drawing.Point(156, 39);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 20);
            this.textBox2.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.Location = new System.Drawing.Point(156, 65);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(120, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Convert";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(27, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "Bit to Hex";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(171, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "Hex to Bit";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 555);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(52, 39);
            this.button3.TabIndex = 8;
            this.button3.Text = "Clear All";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(81, 555);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(51, 39);
            this.button4.TabIndex = 9;
            this.button4.Text = "Check All";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(288, 638);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.checkedListBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkedListBox1);
            this.Name = "Form1";
            this.Text = "Bit to Hex";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckedListBox checkedListBox2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}

