﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadraticEquationCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void calculateButton_Click(object sender, EventArgs e)
        {
            double result = 0;

            result = solveQuadraticEquation(Convert.ToDouble(a.Value), Convert.ToDouble(b.Value), Convert.ToDouble(c.Value), Convert.ToDouble(x.Value));

            answerText.Text = result.ToString();
        }

        /// <summary>
        /// Bu fonksiyon ikinci dereceden denklemin x değerine göre sonucunu verir.
        /// </summary>
        /// <param name="scndAmplitude"></param>
        /// <param name="frstAmplitude"></param>
        /// <param name="cnst"></param>
        /// <param name="X"></param>
        /// <returns></returns>
        private double solveQuadraticEquation(double scndAmplitude, double frstAmplitude, double cnst, double X)
        {
            double FinalResult = 0;

            FinalResult = scndAmplitude * X * X + frstAmplitude * X + cnst;

            return FinalResult;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            a.Maximum = Convert.ToDecimal(Int64.MaxValue);
            a.Minimum = Convert.ToDecimal(Int64.MinValue);
            b.Maximum = Convert.ToDecimal(Int64.MaxValue);
            b.Minimum = Convert.ToDecimal(Int64.MinValue);
            c.Maximum = Convert.ToDecimal(Int64.MaxValue);
            c.Minimum = Convert.ToDecimal(Int64.MinValue);
            x.Maximum = Convert.ToDecimal(Int64.MaxValue);
            x.Minimum = Convert.ToDecimal(Int64.MinValue);
        }
    }
}
